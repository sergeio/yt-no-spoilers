# Youtube No Spoilers

Adds an icon to your toolbar that lets you toggle the extension
on/off.  When on, almost everything on a youtube video page that
is not the video is hidden.  The scrubber / video length is hidden
too.

This is useful when you are watching something on youtube that
could be "spoiled" by being able to see the length of the current
video, or by video recommendations.

[Install](https://addons.mozilla.org/en-US/firefox/addon/youtube-no-spoilers/)
this addon.
